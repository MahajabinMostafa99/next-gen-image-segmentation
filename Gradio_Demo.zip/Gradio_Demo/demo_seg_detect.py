
import gradio as gr
import numpy as np
import h5py
import os
import tensorflow as tf
import matplotlib.pyplot as plt
from skimage.transform import resize

# Load models
unet_model = tf.keras.models.load_model("unet_best.h5")
detector_model = tf.keras.models.load_model("best_detector_iou.h5", compile=False)

os.makedirs("converted", exist_ok=True)

def dice_coef(y_true, y_pred, smooth=1e-6):
    y_true_f = tf.keras.backend.flatten(tf.cast(y_true, tf.float32))
    y_pred_f = tf.keras.backend.flatten(tf.cast(y_pred, tf.float32))
    intersection = tf.reduce_sum(y_true_f * y_pred_f)
    return (2. * intersection + smooth) / (tf.reduce_sum(y_true_f) + tf.reduce_sum(y_pred_f) + smooth)

def mask_to_box(mask):
    if np.sum(mask) == 0:
        return None
    rows = np.any(mask, axis=1)
    cols = np.any(mask, axis=0)
    rmin, rmax = np.where(rows)[0][[0, -1]]
    cmin, cmax = np.where(cols)[0][[0, -1]]
    return [cmin, rmin, cmax, rmax]

def compute_iou_box(boxA, boxB):
    if boxA is None or boxB is None:
        return 0.0
    xA = max(boxA[0], boxB[0])
    yA = max(boxA[1], boxB[1])
    xB = min(boxA[2], boxB[2])
    yB = min(boxA[3], boxB[3])
    interArea = max(0, xB - xA) * max(0, yB - yA)
    boxAArea = (boxA[2] - boxA[0]) * (boxA[3] - boxA[1])
    boxBArea = (boxB[2] - boxB[0]) * (boxB[3] - boxB[1])
    return interArea / float(boxAArea + boxBArea - interArea + 1e-6)

def load_h5_slice(file_path):
    with h5py.File(file_path, 'r') as hf:
        keys = list(hf.keys())
        image_key = next((k for k in keys if 'image' in k.lower()), keys[0])
        image = np.array(hf[image_key])
        if image.ndim == 3 and image.shape[0] <= 4:
            image = np.transpose(image, (1, 2, 0))
        if image.shape[-1] > 4:
            image = image[..., :4]
        image = image.astype(np.float32)
        image = (image - np.min(image)) / (np.max(image) - np.min(image) + 1e-8)
        mask_keys = [k for k in keys if 'mask' in k.lower()]
        mask = np.array(hf[mask_keys[0]]) if mask_keys else np.zeros(image.shape[:2], dtype=np.uint8)
        if mask.ndim == 3:
            mask = mask[..., 0]
        mask = (mask > 0).astype(np.uint8)
        if mask.shape != image.shape[:2]:
            mask = resize(mask, (image.shape[0], image.shape[1]), order=0, mode='constant', cval=0)
    return image, mask

def process_and_save(file):
    image, mask = load_h5_slice(file.name)
    image_resized = resize(image, (128, 128, 4), preserve_range=True, anti_aliasing=True)
    mask_resized = resize(mask, (128, 128), preserve_range=True, order=0, mode='constant')
    mask_resized = (mask_resized > 0.5).astype(np.uint8)

    np.save("converted/X_converted.npy", image_resized)
    np.save("converted/y_converted.npy", mask_resized[..., np.newaxis])
    bbox = mask_to_box(mask_resized)
    if bbox:
        np.save("converted/bbox_converted.npy", np.array(bbox))

    input_img = np.expand_dims(image_resized.astype(np.float32), axis=0)
    pred_mask = unet_model.predict(input_img)[0, ..., 0]
    pred_mask_bin = (pred_mask > 0.5).astype(np.uint8)

    pred_box = detector_model.predict(input_img)[0]
    H, W = 128, 128
    pred_box_abs = (pred_box * [W, H, W, H]).astype(int).tolist()
    true_box = bbox

    dice_score = dice_coef(mask_resized, pred_mask_bin).numpy()
    iou_score = compute_iou_box(pred_box_abs, true_box)

    fig, axs = plt.subplots(1, 3, figsize=(15, 5))
    axs[0].imshow(image_resized[..., 0], cmap='gray')
    axs[0].set_title("MRI (Channel 1)")
    axs[0].axis('off')

    axs[1].imshow(image_resized[..., 0], cmap='gray')
    axs[1].imshow(pred_mask_bin, cmap='hot', alpha=0.5)
    axs[1].set_title(f"Segmentation (Dice: {dice_score:.3f})")
    axs[1].axis('off')

    axs[2].imshow(image_resized[..., 0], cmap='gray')
    if true_box:
        x1, y1, x2, y2 = true_box
        axs[2].add_patch(plt.Rectangle((x1, y1), x2 - x1, y2 - y1,
                                       edgecolor='green', facecolor='none', linewidth=2))
    if pred_box_abs:
        x1, y1, x2, y2 = pred_box_abs
        axs[2].add_patch(plt.Rectangle((x1, y1), x2 - x1, y2 - y1,
                                       edgecolor='red', facecolor='none', linewidth=2))
    axs[2].set_title(f"Detection (IoU: {iou_score:.3f})")
    axs[2].axis('off')

    return fig

# Updated title and description, removed .npy outputs
interface = gr.Interface(
    fn=process_and_save,
    inputs=gr.File(file_types=[".h5"]),
    outputs=gr.Plot(label="MRI Visualization"),
    title="Next-Gen MRI Tumor Segmentation & Detection Demo",
    description="Upload a BRATS2020 `.h5` MRI file. This tool segments tumors, detects bounding boxes, and saves preprocessed data in the background for research use."
)

interface.launch()
